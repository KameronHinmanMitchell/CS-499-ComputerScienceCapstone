///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
// 
//	Modified by Kameron Hinman-Mitchell - SNHU Student, Dec. 12th, 2025
// 
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"


#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	// destroy the created OpenGL textures
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{

	//Creates pencil body texture using mechnical pencil jpg
	this->CreateGLTexture("../../Utilities/textures/me_mech_pen.jpg", "me_mech_pen");
	//Creates pencil tip texture using pencil tip jpg
	this->CreateGLTexture("../../Utilities/textures/me_top_pen.jpg", "me_top_pen");
	//Creates pencil eraser texture using pencil eraser jpg
	this->CreateGLTexture("../../Utilities/textures/me_eraser.jpg", "me_eraser");
	//Creates watch band texture using black jpg
	this->CreateGLTexture("../../Utilities/textures/me_black.jpg", "me_black");
	//Creates power splitter texture using plug jpg
	this->CreateGLTexture("../../Utilities/textures/me_plug.jpg", "me_plug");
	//Creates cuttingboard texture using cuttingboard jpg
	this->CreateGLTexture("../../Utilities/textures/me_cuttingboard.jpg", "me_cuttingboard");
	//Creates wipes can texture using wipes jpg
	this->CreateGLTexture("../../Utilities/textures/me_wipes.jpg", "me_wipes");
	//Creates wipes top texture using wipes top jpg
	this->CreateGLTexture("../../Utilities/textures/me_wipetop.jpg", "me_wipetop");
	//Creates Digital Watch interface using watchback jpg
	this->CreateGLTexture("../../Utilities/textures/me_watchback.jpg", "me_watchback");
	//Creates Gold texture using circular-brushed-gold-texture jpg
	this->CreateGLTexture("../../Utilities/textures/circular-brushed-gold-texture.jpg", "circular-brushed-gold-texture");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

void SceneManager::DefineObjectMaterials()
{

	//creates a wood material for mechanical pencil tip
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 2.0f;
	woodMaterial.ambientStrength = 0.2f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	//creates a matte material for watch band 
	OBJECT_MATERIAL matteMaterial;
	matteMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	matteMaterial.ambientStrength = 0.2f;
	matteMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	matteMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	matteMaterial.shininess = 1.0f;
	matteMaterial.tag = "matteMaterial";
	m_objectMaterials.push_back(matteMaterial);
}


/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	
	m_pShaderManager->use();

	//use custom lighting
	m_pShaderManager->setBoolValue("bUseLighting", true);

	//Light 1 light blue tint with strong focal strength
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(0.3f, 0.0f, 1.4f));
	m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(-4.0f, 2.0f, -2.5f));
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.2f, 0.2f, 1.5f));
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.2f));
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 24.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 5.0f);

	//Light 2 warm yellow tint
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.4f, 0.4f, 0.3f));
	m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(2.0f, 2.0f, 2.0f));
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.6f, 0.6f, 0.4f));
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.2f));
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 20.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 10.0f);

}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	DefineObjectMaterials();
	
	//loads textures into memory
	LoadSceneTextures();

	//loads scene lighting
	SetupSceneLights();

	//loads meshes into memory
	m_basicMeshes->LoadPlaneMesh();		  
	m_basicMeshes->LoadCylinderMesh();    
	m_basicMeshes->LoadConeMesh();        
	m_basicMeshes->LoadTorusMesh();		  
	m_basicMeshes->LoadBoxMesh();		 
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/


	/******************************************************************/
	/***					Cuttingboard Mesh						***/
	/******************************************************************/
	// Draw the cutting board plane first
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(8.0f, 1.0f, 6.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.8f, 0.2f, 0.2f, 1.0f); // Red Plane
	SetShaderTexture("me_cuttingboard");
	SetShaderMaterial("matteMaterial");
	SetTextureUVScale(5.0f, 5.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/******************************************************************/
	/***					Pencil Mesh								***/
	/******************************************************************/
	//Pencil Body
	scaleXYZ = glm::vec3(0.10f, 3.3f, 0.10f); 
	XrotationDegrees = 90.0f; // Rotated to lay flat on the plane
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 20.0f;
	positionXYZ = glm::vec3(-4.0f, 0.16f, -2.5f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 0.0f, 1.0f); // Yellow color for pencil body
	SetShaderTexture("me_mech_pen");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//Pencil Tip
	scaleXYZ = glm::vec3(0.08f, 0.3f, 0.08f); //Tip slightly thiner than body
	XrotationDegrees = -90.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = -20.0f;
	positionXYZ = glm::vec3(-4.0f, 0.16f, -2.5f); // Placed at the front end of pencil body

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.82f, 0.71f, 0.55f, 1.0f); // Light tan for pencil tip
	SetShaderTexture("me_top_pen");
	SetShaderMaterial("wood");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawConeMesh();

	//Eraser 
	scaleXYZ = glm::vec3(0.10f, 0.1f, 0.10f); 
	XrotationDegrees = 90.0f; // Rotated to align with pencil body
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 20.0f;
	positionXYZ = glm::vec3(-5.13f, 0.16f, 0.59f); // Placed at the back end

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 0.75f, 0.8f, 1.0f); // set Pink color for eraser
	SetShaderTexture("me_eraser");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	/******************************************************************/
	/***					Wipe Cylinder Mesh						***/
	/******************************************************************/
	//WipesCylinder
	scaleXYZ = glm::vec3(1.49f, 3.6f, 1.49f);
	XrotationDegrees = 0.0f; 
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(4.20f, 0.0f, -1.55f); 

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 0.0f, 1.0f); //set color of cylinder to yellow
	SetShaderTexture("me_wipetop");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//wipestop
	scaleXYZ = glm::vec3(1.5f, 3.5f, 1.5f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(4.20f, 0.0f, -1.55f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderColor(1.0f, 1.0f, 0.0f, 1.0f); //set color of cylinder to yellow
	SetShaderTexture("me_wipes");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	/******************************************************************/
	/***					Powersplitter Mesh						***/
	/******************************************************************/
	//Powersplitter
	scaleXYZ = glm::vec3(1.00f, 1.0f, 1.00f);
	XrotationDegrees = 90.0f; 
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 45.0f;
	positionXYZ = glm::vec3(1.30f, 0.5f, 1.35f); 

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);  //set color of box to white
	SetShaderTexture("me_plug");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	//Prong 1 Left
	scaleXYZ = glm::vec3(0.18f, 1.12f, 0.2f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 45.0f;
	positionXYZ = glm::vec3(0.50f, 0.38f, 1.7f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("circular-brushed-gold-texture");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	//Prong 2 Right
	scaleXYZ = glm::vec3(0.18f, 1.0f, 0.2f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 45.0f;
	positionXYZ = glm::vec3(0.9f, 0.38f, 2.2f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("circular-brushed-gold-texture");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	//Outlet Grounder
	scaleXYZ = glm::vec3(0.13f, 1.0f, 0.13f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 45.0f;
	positionXYZ = glm::vec3(1.1f, 0.7f, 1.6f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("circular-brushed-gold-texture");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();


	/******************************************************************/
	/***					Watch Mesh								***/
	/******************************************************************/
	//Watch Band
	scaleXYZ = glm::vec3(1.0f, 1.0f, 1.0f);
	XrotationDegrees = 90.0f; 
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.8f, 0.2f, 2.00f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 0.0f, 1.0f);
	SetShaderTexture("me_black");
	SetShaderMaterial("matteMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawTorusMesh();


	//Digital watch
	scaleXYZ = glm::vec3(0.5f, 1.0f, 0.5f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(-2.8f, 0.2f, 3.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 0.0f, 1.0f);
	SetShaderTexture("me_black");
	SetShaderMaterial("matteMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();


	//Digital watch interface
	scaleXYZ = glm::vec3(0.26f, 0.5f, 0.5f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.8f, 0.2f, 3.28f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("me_watchback");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawPlaneMesh();
}